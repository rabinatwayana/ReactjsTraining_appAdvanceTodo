import React, { Component } from 'react'
import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css'; 

export default class ProjectList extends Component {
    handleDelete = (id) => {

    confirmAlert({
      title: 'Delete',
      message: 'Are you sure you want to delete',
      buttons: [
        {
          label: 'Yes',
          //onClick: () => alert('Click Yes')
          onClick: () =>  this.props.handleDelete(id)
        },
        {
          label: 'No',
          onClick: () => alert('Click No')
        }
      ]
    });




       



    }
    handleEdit=(id)=>{
        this.props.handleEdit(id)

    }
    render() {
        let projectList = this.props.projectlist.map((project) =>
            <li key={project.id}>{project.title}:{project.category}<button onClick={() => this.handleEdit(project.id)}>Edit</button><button onClick={() => this.handleDelete(project.id)}>Delete</button></li>)
        return (
            <div>
                <ul>
                    {projectList}
                </ul>

            </div>
        )
    }
}
